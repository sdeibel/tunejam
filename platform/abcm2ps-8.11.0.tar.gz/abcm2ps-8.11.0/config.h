/* config.h.in */

/* uncomment to handle the european A4 format.  */
//#define A4_FORMAT 1

/* uncomment to have ~ as roll instead of twiddle.  */
//#define DECO_IS_ROLL 1

/* comment if you have not mmap() */
#define HAVE_MMAP 1

/* default directory to search for format files */
#define DEFAULT_FDIR "/usr/local/share/abcm2ps"

#define VERSION "8.11.0"
#define VDATE "February 5, 2016"
